﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace AD4212C;

public partial class App : Application
{

}
