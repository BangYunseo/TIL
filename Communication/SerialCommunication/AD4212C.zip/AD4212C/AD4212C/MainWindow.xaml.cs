﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO.Ports;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using System.Reflection;

// AD-4212C RS-232 제어 UI
namespace AD4212C
{
    #region 프로토콜 & 헬퍼 (Cmd / Terminate / Labeled / Converter)
    // 장치 명령 커맨드(Cmd)
    static class Cmd
    {
        // 데이터 요청 & 상태
        public const string Q = "Q";         // 계량 데이터 요구
        public const string S = "S";         // 안정된 계량 데이터 요구
        public const string SIR = "SIR";     // 연속 계량 데이터 요구

        // 장치 제어 & 기능
        public const string C = "C";         // 연속 출력 정지
        public const string CAL = "CAL";     // 캘리브레이션 모드
        public const string P = "P";         // ON/OFF 전원 토글
        public const string PRT = "PRT";     // 프린트(캘리브레이션 모드 사용)
        public const string R = "R";         // 제로 표시
        public const string SMP = "SMP";     // 최소 표시 변경
        public const string U = "U";         // 계량 속도 변경
    }

    // EOL 송신 개행 모드
    public enum TerminateMode 
    {
        // CR/LF – AD-4212C 권장 기본값
        CRLF, 
        CR 
    }

    // UI 표시용 라벨 & 실제 값 쌍
    public record Labeled<T>(string Label, T Value);

    // MultiBinding Value 값 비교 컨버터 (정규화 필요?)
    public class EqualsMultiConverter : IMultiValueConverter
    {
        // 첫 값과 나머지 값들이 모두 같을 경우 true
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values == null || values.Length < 2) { return false; }

            var first = values[0];

            for (int i = 1; i < values.Length; i++)
            {
                if (!Equals(first, values[i])) { return false; }
            }
            return true;
        }

        // 역변환 지원 X
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }
    #endregion

    // 메인 UI
    public partial class MainWindow : Window, INotifyPropertyChanged
    {

        #region Constraints : 상수(고정)
        private const int MAX_LOG_LINES = 500;
        private const int RX_IDLE_FLUSH_MS = 100;
        #endregion

        #region Window.Size : 창 고정 설정
        private void WindowSize_Changed(object sender, SizeChangedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                Width = 800;
                Height = 600;
            }
        }
        #endregion

        #region Window.Close : 창 닫기 설정
        protected override void OnClosing(CancelEventArgs e)
        {
            try { SaveSettings(); } 
            catch { }

            base.OnClosing(e);
        }
        #endregion

        #region RS232C : 메뉴 버튼 설정
        private void RS232C_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Button btn && btn.ContextMenu is ContextMenu cm)
            {
                e.Handled = true;
                btn.ReleaseMouseCapture();
                Mouse.Capture(null);

                cm.PlacementTarget = btn;
                cm.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                cm.StaysOpen = true;
                cm.IsOpen = !cm.IsOpen;

                if (cm.IsOpen)
                {
                    cm.Focus();
                    Keyboard.Focus(cm);
                }
            }
        }

        // Baud Rate 설정 메뉴
        private void BaudRateItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.DataContext is int v)
            {
                SelectedBaudRate = v;
            }
        }
        // Stop Bits 설정 메뉴
        private void StopBitsItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.DataContext is Labeled<StopBits> s)
            {
                SelectedStopBits = s.Value;
            }
        }
        // 패리티 비트 설정 메뉴
        private void ParityItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.DataContext is Labeled<Parity> p)
            {
                SelectedParity = p.Value;
            }
        }
        // 데이터 비트 설정 메뉴
        private void DataBitsItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.DataContext is int v)
            {
                SelectedDataBits = v;
            }
        }
        // Terminate 모드 설정 메뉴
        private void TerminateItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.DataContext is Labeled<TerminateMode> t)
            {
                SelectedTerminate = t.Value;
                try
                {
                    _serialPort.NewLine = (SelectedTerminate == TerminateMode.CRLF) ? "\r\n" : "\r";
                    int avgChars = (SelectedTerminate == TerminateMode.CRLF) ? 22 : 21;
                }
                catch { }
            }
        }
        #endregion

        #region Comm.Port : 포트 설정
        private readonly SerialPort _serialPort;
        #endregion

        #region Comm.RxBuffer : 수신 버퍼
        private readonly StringBuilder _rx = new();
        private readonly object _rxLock = new();
        private string _carry = "";
        private readonly DispatcherTimer _rxTimer;
        private long _lastRxTick;
        #endregion

        #region Comm.CAL : 캘리브레이션 구현
        private bool _isCalibrating = false;
        private enum CalState {
            None,
            AwaitCal0,        
            AwaitEmptyPrint,  
            AwaitPlaceMass,  
            AwaitEnd1,      
            AwaitEnd2
        }
        private CalState _calState = CalState.None;

        private static readonly int[] CalMassOptions = { 0, 50 };
        private int _calMassIndex = 0;
        // 0 -> 50 캘리브레이션
        public int CalTargetMass => CalMassOptions[_calMassIndex];

        private static readonly Regex CalPromptRegex =
            new(@"^\s*CAL\s*0\s*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex CalEndRegex =
            new(@"^\s*End\s*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        #endregion

        #region Comm.Status : 디바이스 상태 표시

        private static readonly Regex ScaleLineRegex =
            new(@"^(?<t>ST|US|QT|WT|OL)\s*,\s*(?<v>[+\- ]?\s*\d+(?:\.\d+)?)\s*(?:g)?\s*$",
                RegexOptions.Compiled | RegexOptions.CultureInvariant);

        private bool _isInitialized = false;
        private bool _isScaleOn = false;
        private bool _isSampleHighPrecision = false;
        private enum ResponseMode { FAST, MID, SLOW }
        private ResponseMode _response = ResponseMode.MID;

        private decimal? _lastWeight;
        private bool _lastOverload;
        private bool _lastStable;
        #endregion

        #region Comm.Binding : 바인딩 프로퍼티

        // 연결 포트 바인딩
        public ObservableCollection<string> Ports { get; } = new();
        private string? _currentPortName;
        public string? CurrentPortName
        {
            get => _currentPortName;
            set {
                if (_currentPortName != value)
                {
                    _currentPortName = value; OnPropertyChanged();
                }
            }
        }

        // 통신 상태 바인딩
        private string _commHealthText = "IDLE";
        public string CommHealthText
        {
            get => _commHealthText;
            set
            {
                if (_commHealthText != value)
                {
                    _commHealthText = value; OnPropertyChanged();
                }
            }
        }

        // 디스플레이 무게 바인딩
        private string _weightText = "0.00";
        public string WeightText
        {
            get => _weightText;
            set
            {
                if (_weightText != value)
                {
                    _weightText = value; OnPropertyChanged();
                }
            }
        }

        // 전송율 설정 바인딩
        public ObservableCollection<int> BaudRates { get; } =
            new() { 600, 1200, 2400, 4800, 9600, 19200, 28800, 38400 };

        private int _selectedBaudRate = 9600;
        public int SelectedBaudRate
        {
            get => _selectedBaudRate;
            set
            {
                if (_selectedBaudRate != value)
                {
                    _selectedBaudRate = value;
                    OnPropertyChanged();
                }
            }
        }

        // 패리티 설정 바인딩
        public ObservableCollection<Labeled<Parity>> ParityOptions { get; } =
            new() { new("E", Parity.Even), new("O", Parity.Odd), new("N", Parity.None) };

        private Parity _selectedParity = Parity.Even;
        public Parity SelectedParity
        {
            get => _selectedParity;
            set { if (_selectedParity != value) { _selectedParity = value; OnPropertyChanged(); } }
        }

        // 데이터 비트 설정 바인딩

        public ObservableCollection<int> DataBitsOptions { get; } = new() { 7, 8 };
        private int _selectedDataBits = 7;
        public int SelectedDataBits
        {
            get => _selectedDataBits;
            set { if (_selectedDataBits != value) { _selectedDataBits = value; OnPropertyChanged(); } }
        }

        // 정지 비트 설정 바인딩
        public ObservableCollection<Labeled<StopBits>> StopBitsOptions { get; } =
            new() { new("1", StopBits.One), new("1.5", StopBits.OnePointFive), new("2", StopBits.Two) };

        private StopBits _selectedStopBits = StopBits.One;
        public StopBits SelectedStopBits
        {
            get => _selectedStopBits;
            set { if (_selectedStopBits != value) { _selectedStopBits = value; OnPropertyChanged(); } }
        }

        // Terminate 모드 설정 바인딩
        public ObservableCollection<Labeled<TerminateMode>> TerminateOptions { get; } =
            new() { new("CR/LF", TerminateMode.CRLF), new("CR", TerminateMode.CR) };

        private TerminateMode _selectedTerminate = TerminateMode.CRLF;
        public TerminateMode SelectedTerminate
        {
            get => _selectedTerminate;
            set
            {
                if (_selectedTerminate != value)
                {
                    _selectedTerminate = value;
                    OnPropertyChanged();
                }
            }
        }
        #endregion

        #region Comm.Send : 명령 전송
        private void Send(string cmd)
        {
            if (!_serialPort.IsOpen) { return; }
            try {
                string t = cmd + "\r";
                if (SelectedTerminate == TerminateMode.CRLF) t += "\n";
                _serialPort.Write(t);
            }
            catch { }
        }
        #endregion

        #region Binding.InotifyPropertyChanged : Notify 전용 프로퍼티
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion

        #region Init : 초기 설정
        // 메인 윈도우 초깃값 설정

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            _serialPort = new SerialPort
            {
                ReadTimeout = 1000,
                WriteTimeout = 1000,
                Encoding = Encoding.ASCII,
                Handshake = Handshake.None,
                DtrEnable = false, 
                RtsEnable = false,
                ReceivedBytesThreshold = 1,
                Parity = Parity.Even,
                DataBits = 7,
                StopBits = StopBits.One,
                NewLine = "\r"
            };

            _rxTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(10) };
            _rxTimer.Tick += RxTimer_Tick;

            Loaded += MainWindow_Loaded;
        }
        // 로드 Window
        private void MainWindow_Loaded(object? sender, RoutedEventArgs e)
        {
            Title = BuildProductTitle();
            RefreshPorts();
            SegAl(false);
            PowerOff.Visibility = Visibility.Collapsed;
            LoadSettings();         
        }
        // 제품 타이틀 작성
        private static string BuildProductTitle()
        {
            var asm = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
            var product = asm.GetCustomAttribute<AssemblyProductAttribute>()?.Product
                          ?? asm.GetName().Name ?? "App";
            var desc = asm.GetCustomAttribute<AssemblyDescriptionAttribute>()?.Description ?? "";
            var v = asm.GetName().Version;
            var ver = v != null ? $" Ver.{v.Major}.{v.Minor}.{v.Build}" : "";
            return product + ver + desc;
        }
        // 안정 표시 & 세그 초기화
        private void SegAl(bool on)
        {
            if (on)
            {
                ZeroSymbol.Visibility = Visibility.Visible; 
                WeightText = "  888888888";
                if (WeightUnit != null) WeightUnit.Visibility = Visibility.Collapsed;
            }
            else
            {
                ZeroSymbol.Visibility = Visibility.Collapsed;
                WeightText = "";
                if (WeightUnit != null) WeightUnit.Visibility = Visibility.Visible;
            }
            SetResponseIndicators();
        }

        // 기존 설정 로드
        private void LoadSettings()
        {
            try
            {
                var s = AppSettings.Default;

                int baud = s.BaudRate > 0 ? s.BaudRate : 19200;
                var parity = Enum.IsDefined(typeof(Parity), s.Parity) ? (Parity)s.Parity : Parity.Even;
                int data = (s.DataBits == 7 || s.DataBits == 8) ? s.DataBits : 7;
                var stop = Enum.IsDefined(typeof(StopBits), s.StopBits) ? (StopBits)s.StopBits : StopBits.One;
                var term = Enum.IsDefined(typeof(TerminateMode), s.Terminator)
                            ? (TerminateMode)s.Terminator
                            : TerminateMode.CRLF;

                SelectedBaudRate = baud;
                SelectedParity = parity;
                SelectedDataBits = data;
                SelectedStopBits = stop;
                SelectedTerminate = term;

                var savedPort = s.Port;
                if (!string.IsNullOrWhiteSpace(savedPort) && Ports.Contains(savedPort))
                {
                    CurrentPortName = savedPort;
                    if (PortComboBox != null) PortComboBox.SelectedItem = savedPort;
                }
                else
                {
                    CurrentPortName = Ports.FirstOrDefault();
                    if (PortComboBox != null) PortComboBox.SelectedItem = CurrentPortName;
                }
            }
            catch { }
        }
        // 기존 설정 저장
        private void SaveSettings()
        {
            try
            {
                var s = AppSettings.Default;
                s.Port = CurrentPortName ?? "";
                s.BaudRate = SelectedBaudRate;
                s.Parity = (int)SelectedParity;
                s.DataBits = SelectedDataBits;
                s.StopBits = (int)SelectedStopBits;
                s.Terminator = (int)SelectedTerminate;
                s.Save();
            }
            catch { }
        }
        #endregion

        #region Receive : 수신 처리
        // 원시 바이트 수집
        private void SerialPort_DataReceived(object? s, SerialDataReceivedEventArgs e)
        {
            try
            {
                var sp = (SerialPort)s!;
                int toRead = sp.BytesToRead;
                if (toRead <= 0) { return; }

                var buf = new byte[toRead];
                int n = sp.Read(buf, 0, buf.Length);
                if (n <= 0) { return; }

                lock (_rxLock)
                {
                    _rx.Append(Encoding.ASCII.GetString(buf, 0, n));
                    _lastRxTick = Environment.TickCount64;
                }
            }
            catch { }
        }

        // 프레임 분리
        private void RxTimer_Tick(object? sender, EventArgs e)
        {
            string text;
            lock (_rxLock)
            {
                text = _carry + _rx.ToString();
                _rx.Clear();
            }

            bool produced = false;

            while (true)
            {
                int i = text.IndexOf('\r');
                if (i < 0) { break; }

                string frame = text[..i];
                text = text[(i + 1)..];

                if (frame.Length > 0 && frame[0] == '\n') { frame = frame[1..]; }
                
                _carry = "";
                ProcessFrame(frame);

                produced = true;
            }

            if (!produced)
            {
                if (text.Length > 0)
                {
                    long idle = Environment.TickCount64 - _lastRxTick;
                    if (idle > RX_IDLE_FLUSH_MS)
                    {
                        _carry = "";
                        ProcessFrame(text);
                    }
                    else
                    {
                        _carry = text;
                    }
                }
                else
                {
                    _carry = "";
                }
            }
        }

        // 프레임 해석 & 상태 갱신
        private void ProcessFrame(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) { return; }

            var line = s.Trim();
            switch (line.Length >= 3 ? line[..3] : line)
            {
                case "@RE": COM_RE(line); return;
                case "@ST": COM_ST(line); return;
                case "@CH": COM_CH(line); return;
                case "@DP": COM_DP(line); return;
                case "@AL": SegAl(true); return;
                case "@CL": SegAl(false); return;
            }


            if (TryParseScaleLine(s, out bool stable, out bool overload, out decimal w))
            {
                _lastStable = stable;
                _lastOverload = overload;

                if (!overload) { _lastWeight = w; }

                if (WeightUnit != null) WeightUnit.Visibility = _isScaleOn ? Visibility.Visible : Visibility.Collapsed;

                RenderWeight();
                AppendMeasurementLog(s, overload, w);
            }
        }

        // 쉼표 뒤 파싱
        private static string? AfterComma(string s)
        {
            int i = s.IndexOf(',');
            if (i < 0 || i + 1 >= s.Length) return null;
            return s[(i + 1)..].Trim();
        }
        // s: "@RE,xx"
        private void COM_RE(string s)
        {
            _responsePanelActivated = true;

            var field = AfterComma(s);
            if (string.IsNullOrEmpty(field)) return;
            if (!int.TryParse(field, NumberStyles.Integer, CultureInfo.InvariantCulture, out int bits)) return;

            var m = _response;
            if ((bits & 0x01) != 0) m = ResponseMode.SLOW;
            else if ((bits & 0x02) != 0) m = ResponseMode.MID;
            else if ((bits & 0x04) != 0) m = ResponseMode.FAST;

            if (m != _response) { _response = m; SetResponseIndicators(); }
        }

        // s: "@ST,xx"
        private void COM_ST(string s)
        {
            var field = AfterComma(s);
            if (string.IsNullOrEmpty(field)) return;

            if (!int.TryParse(field, NumberStyles.Integer, CultureInfo.InvariantCulture, out int bits)) return;

            ZeroSymbol.Visibility = ((bits & 0x08) != 0) ? Visibility.Visible : Visibility.Collapsed;
        }

        // s: "@CH,...."
        private void COM_CH(string s)
        {
            var raw = AfterComma(s);
            if (string.IsNullOrEmpty(raw)) return;

            WeightText = "  " + raw;

            ZeroSymbol.Visibility = Visibility.Collapsed;
            if (WeightUnit != null) WeightUnit.Visibility = Visibility.Collapsed;
        }

        // s: "@DP,xxx"
        private void COM_DP(string s)
        {
            var field = AfterComma(s);
            if (string.IsNullOrEmpty(field)) return;
            if (!int.TryParse(field, NumberStyles.Integer, CultureInfo.InvariantCulture, out int bits)) return;

            int highest = 0;
            for (int p = 1; p <= 6; p++)
                if ((bits & (1 << p)) != 0) highest = p;

            string value = "";
            if (highest > 0)
            {
                value = " .";
                for (int i = 0; i <= 6 - highest; i++) value = " " + value;
            }

            WeightText = value;
            ZeroSymbol.Visibility = Visibility.Collapsed;
            if (WeightUnit != null) WeightUnit.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region UI.Display : UI 디스플레이 상태 표시
        // 디스플레이 상태 업데이트
        private void UpdateDisplay()
        {
            if (!_isInitialized)
            {
                PowerOff.Visibility = Visibility.Collapsed;
                PowerOnTestDisplay.Visibility = Visibility.Collapsed;
                ResponseModePanel.Visibility = Visibility.Collapsed;
                ZeroSymbol.Visibility = Visibility.Collapsed;
                WeightPanel.Visibility = Visibility.Collapsed;
                return;
            }

            PowerOff.Visibility = _isScaleOn ? Visibility.Collapsed : Visibility.Visible;
            PowerOnTestDisplay.Visibility = Visibility.Collapsed;
            WeightPanel.Visibility = _isScaleOn ? Visibility.Visible : Visibility.Collapsed;
            if (!_isScaleOn) ZeroSymbol.Visibility = Visibility.Collapsed;

            SetResponseIndicators();
        }
        // 디스플레이 MODE 변환 표시
        private void SetResponseIndicators()
        {
            ResponseModePanel.Visibility = (_isScaleOn && _responsePanelActivated)
        ? Visibility.Visible : Visibility.Collapsed;

            ModeLeft.Visibility = (_response == ResponseMode.FAST) ? Visibility.Visible : Visibility.Collapsed;
            ModeCenter.Visibility = (_response == ResponseMode.MID) ? Visibility.Visible : Visibility.Collapsed;
            ModeRight.Visibility = (_response == ResponseMode.SLOW) ? Visibility.Visible : Visibility.Collapsed;
        }
        // 디스플레이 무게 표시
        private void RenderWeight()
        {
            if (_lastOverload) { WeightText = "OL"; ZeroSymbol.Visibility = Visibility.Collapsed; return; }

            int decimals = _isSampleHighPrecision ? 3 : 2;
            var w = _lastWeight ?? 0m;
            WeightText = w.ToString(decimals == 3 ? "0.000" : "0.00", CultureInfo.InvariantCulture);

            ZeroSymbol.Visibility = (_isScaleOn && _lastStable) ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region UI.Port : 포트 관련 UI 설정
        // 연결 포트 탐색
        private void PortComboBox_DropDownOpened(object sender, EventArgs e)
            => RefreshPorts();
        private void RefreshPorts()
        {
            var prev = CurrentPortName;
            var latest = SerialPort.GetPortNames()
                                   .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                                   .ToArray();

            Ports.Clear();
            foreach (var p in latest) Ports.Add(p);

            if (!string.IsNullOrEmpty(prev) && latest.Contains(prev))
            {
                CurrentPortName = prev;
                if (PortComboBox.Items.Count > 0) PortComboBox.SelectedItem = prev;
            }
            else
            {
                CurrentPortName = null;
                PortComboBox.SelectedIndex = -1;
            }
        }
        // 포트 창 열림 설정
        private void PortComboBox_DropDownClosed(object sender, EventArgs e)
        {
            if (PortComboBox.SelectedIndex < 0 && Ports.Count > 0)
                PortComboBox.SelectedIndex = 0;
            CurrentPortName = PortComboBox.SelectedItem as string;
        }

        // 포트 선택 설정
        private void PortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
            => CurrentPortName = PortComboBox.SelectedItem as string;
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
        #endregion

        #region UI.Buttons : UI 버튼(6개) 작동
        // ON/OFF 버튼
        private void OnOffButton_Click(object sender, RoutedEventArgs e) => Send(Cmd.P);
        
        // CAL 버튼
        private void CalButton_Click(object sender, RoutedEventArgs e)
        {
            Send(Cmd.CAL);
        }

        // PRINT 버튼 : 캘리브레이션 연동
        private void PrintButton_Click(object sender, RoutedEventArgs e) => Send(Cmd.PRT);

        // SAMPLE 버튼
        private void SampleButton_Click(object sender, RoutedEventArgs e)
        {
            _isSampleHighPrecision = !_isSampleHighPrecision;     
            RenderWeight();

            Send(Cmd.SMP);
        }

        // MODE 버튼

        // UI 표시
        private bool _responsePanelActivated = false;
        private void ModeButton_Click(object sender, RoutedEventArgs e)
        {
            _responsePanelActivated = true;
            SetResponseIndicators();
            Send(Cmd.U);
        }

        // RE-ZERO 버튼
        private void ReZeroButton_Click(object sender, RoutedEventArgs e)
        {
            Send("R");
            SegAl(false);
        }
        #endregion

        #region Text.Parse : 문자열 수신 후 변환
        private static bool TryParseScaleLine(string line, out bool stable, out bool overload, out decimal value)
        {
            stable = false;
            overload = false;
            value = 0m;
            var m = ScaleLineRegex.Match(line);

            if (!m.Success) { return false; }

            string t = m.Groups["t"].Value;
            overload = (t == "OL");
            stable = (t == "ST" || t == "QT" || t == "WT");
            if (overload) { return true; }

            var raw = m.Groups["v"].Value.Replace(" ", "");
            return decimal.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }
        #endregion

        #region Text.Format : 문자열 포맷팅 변환
        private static string FormatSigned(decimal v, int decimals, int leftDigits = 5)
        {
            var sign = v < 0 ? "-" : "+";
            var abs = Math.Abs(v);
            string fmt = new string('0', leftDigits) + "." + new string('0', decimals);
            return sign + abs.ToString(fmt, CultureInfo.InvariantCulture);
        }
        #endregion

        #region Text.Logging : 로깅 구현
        // 측정 로그 출력
        private void AppendMeasurementLog(string raw, bool overload, decimal value)
        {
            if (!_isScaleOn) { return; }
            if (LoggingCheckBox?.IsChecked != true) { return; }

            string type = raw.Split(',')[0].Trim();
            int decimals = _isSampleHighPrecision ? 3 : 2;

            string fixedVal = overload
                ? "OL".PadLeft(1 + 5 + 1 + decimals)
                : FormatSigned(value, decimals, 5);

            LogTextBox.AppendText($"{type},{fixedVal}  g,{DateTime.Now:HH:mm:ss}\r\n");
            LogTextBox.ScrollToEnd();
            TrimLogLines();
        }
        private void TrimLogLines(int maxLines = MAX_LOG_LINES)
        {
            if (LogTextBox == null) return;
            if (LogTextBox.LineCount <= maxLines) return;

            int remove = LogTextBox.LineCount - maxLines;
            if (remove <= 0) return;

            int start = LogTextBox.GetCharacterIndexFromLineIndex(0);
            int end = LogTextBox.GetCharacterIndexFromLineIndex(remove);
            LogTextBox.Select(start, end - start);
            LogTextBox.SelectedText = string.Empty;
        }

        // 단순 정의 
        private void LoggingCheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
        private void LoggingCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        // 로깅 내역 삭제
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            ConfirmClearLog();
        }
        private bool ConfirmClearLog()
        {
            if (LogTextBox == null) return true;

            if (string.IsNullOrWhiteSpace(LogTextBox.Text))
                return true;

            var result = MessageBox.Show("Will you clear this data?",
                                         "WinCT for AD4212C",
                                         MessageBoxButton.YesNoCancel,
                                         MessageBoxImage.Warning);

            if (result == MessageBoxResult.Cancel)
                return false;

            if (result == MessageBoxResult.Yes)
            {
                LogTextBox.Clear();
                LogTextBox.ScrollToEnd();
            }
            return true;
        }

        // 로깅 내역 저장
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ts = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                var dlg = new SaveFileDialog
                {
                    Title = "Save Log",
                    Filter = "Text file (*.txt)|*.txt|All files (*.*)|*.*",
                    FileName = $"log_{ts}.txt",
                    AddExtension = true,
                    DefaultExt = ".txt",
                    OverwritePrompt = true
                };

                if (dlg.ShowDialog(this) == true)
                {
                    System.IO.File.WriteAllText(dlg.FileName, LogTextBox.Text, Encoding.UTF8);
                    MessageBox.Show("Saved.", "WinCT for AD4212C",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save failed: " + ex.Message,
                                "WinCT for AD4212C",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        #endregion

        #region Port.Connect : 포트 연결 및 설정
        // 포트 연결 및 데이터 송수신 시작
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            SaveSettings();

            if (!_serialPort.IsOpen)
            {
                if (string.IsNullOrWhiteSpace(CurrentPortName))
                {
                    MessageBox.Show("Can not Open !\rPlease Check Setting of Com Port !",
                                    "WinCT for AD4212C",
                                    MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!RsOpen()) {return; }
                StartButton.Content = "   Stop   ";
            }
            else
            {
                RsClose();                
                _isInitialized = false;
                _isScaleOn = false;
                UpdateDisplay();
                StartButton.Content = "   Start   ";
            }
        }


        // 포트 Baud Rate Setting 시작
        private async void SetButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (PortComboBox.SelectedItem is not string portName)
                { MessageBox.Show("Select your port first."); return; }

                CurrentPortName = portName;

                if (_serialPort.IsOpen)
                {
                    try { _serialPort.DataReceived -= SerialPort_DataReceived; } catch { }
                    try { _serialPort.Close(); } catch { }
                }

                RsSet();

                _serialPort.DataReceived -= SerialPort_DataReceived;
                _serialPort.DataReceived += SerialPort_DataReceived;
                _serialPort.Open();

                long before = _lastRxTick;                  
                var start = Environment.TickCount64;
                // 2초 대기
                while (Environment.TickCount64 - start < 2000 && _lastRxTick == before)
                    await Task.Delay(20);                  

                if (_serialPort.IsOpen && _lastRxTick != before)
                    MessageBox.Show("Completed !", "WinCT for AD4212C", MessageBoxButton.OK, MessageBoxImage.Information);
                else
                    MessageBox.Show("No device response..", "WinCT for AD4212C", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception) { RsClose(); }
        }
        private void RsSet()
        {
            if (string.IsNullOrWhiteSpace(CurrentPortName))
                throw new InvalidOperationException("Port not selected.");

            _serialPort.PortName = CurrentPortName;
            _serialPort.BaudRate = SelectedBaudRate;  
            _serialPort.Parity = SelectedParity; 
            _serialPort.DataBits = SelectedDataBits;  
            _serialPort.StopBits = SelectedStopBits;

            _serialPort.NewLine = (SelectedTerminate == TerminateMode.CRLF) ? "\r\n" : "\r";


            _serialPort.DtrEnable = true;
            _serialPort.RtsEnable = true;
        }

        private bool _hasFirstWeight = false;

        private bool RsOpen(bool activeUi = true)
        {
            try
            {
                RsSet();

                if (!_serialPort.IsOpen)
                {
                    if (activeUi)
                    {
                        _serialPort.DataReceived -= SerialPort_DataReceived;
                        _serialPort.DataReceived += SerialPort_DataReceived;
                    }
                    _serialPort.Open();
                    if (activeUi) _rxTimer.Start();
                }

                if (activeUi)
                {
                    _isInitialized = true;
                    _isScaleOn = true;

                    _hasFirstWeight = false;
                    SegAl(on: true);
                    UpdateDisplay();
                }
                return true;
            }
            catch
            {
                MessageBox.Show("Can not Open !",
                                "WinCT for AD4212C",
                                MessageBoxButton.OK, 
                                MessageBoxImage.Warning);
                return false;
            }
        }

        private void RsClose()
        {
            try { if (_serialPort.IsOpen) _serialPort.Close(); } 
            catch { }

            _rxTimer.Stop();
        }

        #endregion
    }
}