﻿using System.Configuration;
using System.IO.Ports;

namespace AD4212C;

[SettingsProvider(typeof(LocalFileSettingsProvider))]
internal sealed class AppSettings : ApplicationSettingsBase
{
    private static readonly AppSettings _default =
        (AppSettings)Synchronized(new AppSettings());
    public static AppSettings Default => _default;

    [UserScopedSetting, DefaultSettingValue("")]
    public string Port
    {
        get => (string)this[nameof(Port)];
        set => this[nameof(Port)] = value;
    }

    [UserScopedSetting, DefaultSettingValue("19200")]
    public int BaudRate
    {
        get => (int)this[nameof(BaudRate)];
        set => this[nameof(BaudRate)] = value;
    }

    [UserScopedSetting, DefaultSettingValue("2")] 
    public int Parity
    {
        get => (int)this[nameof(Parity)];
        set => this[nameof(Parity)] = value;
    }

    [UserScopedSetting, DefaultSettingValue("7")]
    public int DataBits
    {
        get => (int)this[nameof(DataBits)];
        set => this[nameof(DataBits)] = value;
    }

    [UserScopedSetting, DefaultSettingValue("1")] 
    public int StopBits
    {
        get => (int)this[nameof(StopBits)];
        set => this[nameof(StopBits)] = value;
    }

    [UserScopedSetting, DefaultSettingValue("1")]
    public int Terminator
    {
        get => (int)this[nameof(Terminator)];
        set => this[nameof(Terminator)] = value;
    }
}
